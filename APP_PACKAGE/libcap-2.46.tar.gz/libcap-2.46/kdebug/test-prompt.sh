#!/bin/sh
echo -n "$(pwd)# "
